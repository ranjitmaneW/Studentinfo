package com.example.demo.Entity;

import java.time.LocalDateTime;

import com.example.demo.Enum.Mode;
import com.example.demo.Enum.Status;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data

@Entity
@AllArgsConstructor
@NoArgsConstructor
public class Appointment {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	
	private Long id;
	private LocalDateTime appointmentDate;

    @Enumerated(EnumType.STRING)
    private Status status;
    
    private String remarks;
    
    @Enumerated(EnumType.STRING)
    private Mode mode;
    
    private String createdBy;
  // @JsonIgnore
    
    @ManyToOne
    @JoinColumn(name = "patient_id", nullable = false)
    
    private Patient patient;

    
    @ManyToOne
    @JoinColumn(name = "doctor_id", nullable = false)
    private Doctor doctor;

    
	


   // private Bill bill;

}
