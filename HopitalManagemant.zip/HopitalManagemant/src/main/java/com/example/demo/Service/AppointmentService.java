package com.example.demo.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Appointment;
import com.example.demo.Entity.Doctor;
import com.example.demo.Entity.Patient;
import com.example.demo.Repository.AppointmentRepository;
import com.example.demo.Repository.DoctorRepository;
import com.example.demo.Repository.PatientRepository;

@Service
public class AppointmentService {

    @Autowired
    private AppointmentRepository appointmentRepository;
    
    @Autowired
    private PatientRepository patientRepository;
    
    @Autowired
    private DoctorRepository doctorRepository;
    public Appointment saveAppointmentData(Appointment appointment) {
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment object is null");
        }

        Patient patient = appointment.getPatient();
        if (patient != null && patient.getEmail() != null) {
            Patient existingPatient = patientRepository.findByEmail(patient.getEmail());
            if (existingPatient != null) {
                appointment.setPatient(existingPatient);
            } else {
                Patient savedPatient = patientRepository.save(patient);
                appointment.setPatient(savedPatient);
            }
        } else {
            throw new IllegalArgumentException("Patient data or email is null");
        }

        Doctor doctor = appointment.getDoctor();
        if (doctor != null) {
            if (doctor.getId() == null) {
                Doctor savedDoctor = doctorRepository.save(doctor);
                appointment.setDoctor(savedDoctor);
            }
        } else {
            throw new IllegalArgumentException("Doctor data is null");
        }

        return appointmentRepository.save(appointment);
    }



    // Get a list of all appointments
    public List<Appointment> listOfAppointment() {
        return appointmentRepository.findAll();
    }

    // Get appointment by ID
    public Optional<Appointment> getAppointmentDataById(long id) {
        return appointmentRepository.findById(id);
    }

    // Delete appointment by ID
    public String deleteAppointmentDataById(long id) {
        if (appointmentRepository.existsById(id)) {
            appointmentRepository.deleteById(id);
            return "Appointment record deleted by " + id + " successfully";
        } else {
            return "Appointment record not found";
        }
    }

    // Update appointment by ID
    public String updateAppointmentDataById(long id, Appointment appointment) {
        Optional<Appointment> byId = appointmentRepository.findById(id);

        if (byId.isPresent()) {
            Appointment existingAppointment = byId.get();

            existingAppointment.setAppointmentDate(appointment.getAppointmentDate());
            existingAppointment.setStatus(appointment.getStatus());
            existingAppointment.setRemarks(appointment.getRemarks());
            existingAppointment.setMode(appointment.getMode());
            existingAppointment.setCreatedBy(appointment.getCreatedBy());
            
            appointmentRepository.save(existingAppointment);
            return "Appointment data updated for ID: " + id;
        } else {
            return "Appointment data not found for ID: " + id;
        }
    }
}
