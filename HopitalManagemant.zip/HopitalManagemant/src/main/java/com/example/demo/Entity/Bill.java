package com.example.demo.Entity;

import java.time.LocalDateTime;


import com.example.demo.Enum.PaymentMethod;
import com.example.demo.Enum.Status1;
import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;

import jakarta.persistence.ManyToOne;

import jakarta.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Data


public class Bill {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	
	private Long id;
	@OneToOne
	@JoinColumn(name = "appointment_id", referencedColumnName = "id")
	private Appointment appointment;
	
	private Double amount;
	private LocalDateTime paidDate;
	
	@Enumerated(EnumType.STRING)
	private Status1 status;
	
	@Enumerated(EnumType.STRING)
	private PaymentMethod paymentMethod;
	

	
	@ManyToOne
	@JoinColumn(name = "Patient_id")
	@JsonIgnore
	private Patient patient;

	
	
     
	/* patient: Patient (ManyToOne)
	  appointment: Appointment (OneToOne)
	  amount: Double
	 paymentMethod: Enum (CASH, CARD, UPI, INSURANCE)
	  status: Enum (PAID, UNPAID)
	  paidDate: LocalDateTime*/

}
