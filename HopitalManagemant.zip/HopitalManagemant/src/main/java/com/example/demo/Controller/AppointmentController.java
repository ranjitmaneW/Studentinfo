package com.example.demo.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.ApiResponse.ApiResponse;
import com.example.demo.Entity.Appointment;
import com.example.demo.Service.AppointmentService;

@RestController

public class AppointmentController {
	
	@Autowired
	AppointmentService appointmentService;
	
	@PostMapping("/InsertAppointmentData")
	public ResponseEntity<ApiResponse> saveAppointmentData(@RequestBody Appointment appointment) {
	    Appointment savedAppointment = appointmentService.saveAppointmentData(appointment);
	    ApiResponse response = new ApiResponse("Appointment Data Inserted", 201, savedAppointment);
	    return ResponseEntity.status(HttpStatus.CREATED).body(response);
	}

	@GetMapping("/AppointmentList")
	

	 public ResponseEntity<ApiResponse> getAppointmentData(){
		List<Appointment> getadata=appointmentService.listOfAppointment();
	    	ApiResponse response=new ApiResponse("Appointment List Created ",202,getadata);
			return ResponseEntity.status(HttpStatus.OK).body(response);
	    	
	    }
	
	@GetMapping("/GetAppointmentById/{id}")
	
	public ResponseEntity<ApiResponse> getADataById(@PathVariable("id")long id){
		Optional<Appointment> getAById=appointmentService.getAppointmentDataById(id);
	    	ApiResponse response=new ApiResponse("Get Staff Data By Id ",204,getAById);
			return ResponseEntity.status(HttpStatus.ACCEPTED).body(response);
	    	
	    }
	@DeleteMapping("/DeleteAppointmentById/{id}")
	
	 public ResponseEntity<ApiResponse> deleteAData(@PathVariable("id")long id){
		String deleteAById=appointmentService.deleteAppointmentDataById(id);
	    	ApiResponse response=new ApiResponse("Deleted Appointment Data By Id ",202,deleteAById);
			return ResponseEntity.status(HttpStatus.OK).body(response);
	    	
	    }
	
	@PutMapping("/UpdateAppointmentDataById/{id}")
	
	 public ResponseEntity<ApiResponse> updateAData(@PathVariable("id")long id,@RequestBody Appointment appointment){
		String updateAById=appointmentService.updateAppointmentDataById(id, appointment);
	    	ApiResponse response=new ApiResponse("Updated Prescription Data By Id ",202,updateAById);
			return ResponseEntity.status(HttpStatus.OK).body(response);
	    	
	    }
	


}
