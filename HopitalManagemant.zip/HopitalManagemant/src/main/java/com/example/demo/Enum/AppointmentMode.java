package com.example.demo.Enum;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum AppointmentMode {
    ONLINE, OFFLINE, BOTH;

      @JsonCreator
	    public static AppointmentMode fromString(String value) {
	        return AppointmentMode.valueOf(value.toUpperCase());
	    }

}
