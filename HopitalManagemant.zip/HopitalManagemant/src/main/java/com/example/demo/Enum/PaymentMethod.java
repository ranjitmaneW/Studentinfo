package com.example.demo.Enum;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum PaymentMethod {
	CASH,
	CARD,
	UPI,
	NETBANKING,
	INSURANCE;
	
	@JsonCreator
    public static PaymentMethod fromString(String value) {
        return PaymentMethod.valueOf(value.toUpperCase());
    }

}
