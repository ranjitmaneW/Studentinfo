package com.example.demo.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.ApiResponse.ApiResponse;
import com.example.demo.Entity.Prescription;
import com.example.demo.Service.PrescriptionService;

@RestController

public class PrescriptionController {
	
	@Autowired
	PrescriptionService prescriptionService;

	
	@PostMapping("/InsertPrescriptionData")
	
	 public ResponseEntity<ApiResponse> savePrescriptionData(@RequestBody Prescription prescription){
		Prescription savepdata=prescriptionService.saveData(prescription);
	    	ApiResponse response=new ApiResponse("Prescription Data Inserted",201,savepdata);
			return ResponseEntity.status(HttpStatus.CREATED).body(response);
	    	
	    }
	
	@GetMapping("/PriscriptionList")
	

	 public ResponseEntity<ApiResponse> getPriscriptionData(){
		List<Prescription> getpdata=prescriptionService.listOfPrescription();
	    	ApiResponse response=new ApiResponse("Prescription List Created ",202,getpdata);
			return ResponseEntity.status(HttpStatus.OK).body(response);
	    	
	    }
	
	@GetMapping("/GetPrescriptionById/{id}")
	
	public ResponseEntity<ApiResponse> getPDataById(@PathVariable("id")long id){
		Optional<Prescription> getPById=prescriptionService.getPrescriptionDataById(id);
	    	ApiResponse response=new ApiResponse("Get Prescription Data By Id ",204,getPById);
			return ResponseEntity.status(HttpStatus.ACCEPTED).body(response);
	    	
	    }
	@DeleteMapping("/DeletePrescriptionById/{id}")
	
	 public ResponseEntity<ApiResponse> deletePData(@PathVariable("id")long id){
		String deletePById=prescriptionService.deletePrescriptionDataById(id);
	    	ApiResponse response=new ApiResponse("Deleted Prescription Data By Id ",202,deletePById);
			return ResponseEntity.status(HttpStatus.OK).body(response);
	    	
	    }
	
	@PutMapping("/UpdatePrescriptionDataById/{id}")
	
	 public ResponseEntity<ApiResponse> updatePData(@PathVariable("id")long id,@RequestBody Prescription prescription){
		String updatePById=prescriptionService.updatePrescriptionDataById(id, prescription);
	    	ApiResponse response=new ApiResponse("Updated Prescription Data By Id ",202,updatePById);
			return ResponseEntity.status(HttpStatus.OK).body(response);
	    	
	    }
	
}
