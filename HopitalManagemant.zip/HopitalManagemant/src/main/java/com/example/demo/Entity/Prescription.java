package com.example.demo.Entity;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Prescription {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	
	
	
	private Long id;
	
	 @OneToOne
	    @JoinColumn(name = "appointment_id", referencedColumnName = "id")
	    private Appointment appointment;  
	 
	//private String appointment;
	private String diagnosis;
	private List<String> medicines;
	private List<String> testRecommended;
	private String notes;
	

}
