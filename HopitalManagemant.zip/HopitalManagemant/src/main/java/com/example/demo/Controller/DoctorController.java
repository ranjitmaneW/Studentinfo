package com.example.demo.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.ApiResponse.ApiResponse;
import com.example.demo.Entity.Doctor;
import com.example.demo.Service.DoctorService;


@RestController
public class DoctorController {
	
	@Autowired
	private DoctorService doctorService;
	
	
	/*@PostMapping("/AddDoctor")
    public Doctor addDoctor(@RequestBody Doctor d) {
        return doctorService.addDoctor(d);
    }
	
	
    @GetMapping("/AllDoctors")
    public List<Doctor> getAllDoctors() {
        return doctorService.getAllDoctors();
    }
    
    @GetMapping("/DoctorById/{id}")
    public Optional<Doctor> getDoctorById(@PathVariable("id") long id) {
        return doctorService.getDoctorById(id);
    }
    
    @PutMapping("/Update/{id}")
    public String updateDoctor(@PathVariable("id") long id, @RequestBody Doctor d) {
        return doctorService.updateDoctor(id, d);
    }
    
    
    @GetMapping("/Specialization/{spec}")
    public List<Doctor> getDoctorBySpecialization(@PathVariable("spec") String spec) {
        return doctorService.getDoctorBySpecialization(spec);
    }*/

    
    @PostMapping("/InsertDoctorData")
	public ResponseEntity<ApiResponse> savedata(@RequestBody Doctor d){
		Doctor doctordata=doctorService.addDoctor(d);
        ApiResponse response=new ApiResponse("Doctor data created ", HttpStatus.CREATED.value(), doctordata);
		return ResponseEntity.status(HttpStatus.CREATED).body(response);
		
	}
	
	@GetMapping("/DoctorsList")
	public ResponseEntity<ApiResponse> getalldatalist(){
		List<Doctor> getlist =doctorService.getAllDoctors();
		ApiResponse response = new ApiResponse("Data retrived Successfully",HttpStatus.ACCEPTED.value(), getlist);
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(response);
		
	}

    @GetMapping("/FindDoctorById/{id}")
	public ResponseEntity<ApiResponse> getDataById(@PathVariable("id") long id){
		Optional<Doctor> getById =doctorService.getDoctorById(id);
		ApiResponse response = new ApiResponse("Data retrived Successfully",HttpStatus.ACCEPTED.value(), getById);
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(response);
		
	}

    @GetMapping("/Specialization/{spec}")
	public ResponseEntity<ApiResponse> getData(@PathVariable("spec") String spec){
		List<Doctor> getBySpec =doctorService.getDoctorBySpecialization(spec);
		ApiResponse response = new ApiResponse("Data retrived Successfully",HttpStatus.ACCEPTED.value(), getBySpec);
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(response);
		
	}

    @PutMapping("/UpdateDoctor/{id}")
    public ResponseEntity<ApiResponse> updatedoctor(@PathVariable("id") long id,@RequestBody Doctor d){
        String updatedoctor=doctorService.updateDoctor(id,d);
        ApiResponse response = new ApiResponse("Data Updated Successfully", HttpStatus.ALREADY_REPORTED.value(), updatedoctor);
        return ResponseEntity.status(HttpStatus.ALREADY_REPORTED).body(response);
    }
	
    

}
