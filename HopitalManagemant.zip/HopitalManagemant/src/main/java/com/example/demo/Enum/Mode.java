package com.example.demo.Enum;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum Mode {
	ONLINE,
	OFFLINE;
	

	 @JsonCreator
	    public static Mode fromString(String value) {
	        return Mode.valueOf(value.toUpperCase());
	    }

}
