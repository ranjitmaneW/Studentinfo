package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.Entity.Room;
import com.example.demo.Service.RoomService;


@RestController
public class RoomController {
	
    @Autowired
    private RoomService roomService;
  
    
    @PostMapping("/InsertRoom")
    public ResponseEntity<Room> saveRoom(@RequestBody Room room) {
        Room savedRoom = roomService.saveRoom(room);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedRoom);
    }

    @GetMapping("/AllRooms")
    public ResponseEntity<List<Room>> getAllRooms() {
        return ResponseEntity.ok(roomService.getAllRooms());
    }

    @GetMapping("/AvailableRoom")
    public ResponseEntity<List<Room>> getAvailableRooms() {
        return ResponseEntity.ok(roomService.getAvailableRooms());
    }

    @PutMapping("/UpdateRoom/{id}")
    public ResponseEntity<String> updateRoom(@PathVariable("id") long id, @RequestBody Room room) {
        roomService.updateRoom(id,room);
        return ResponseEntity.ok("Room Updated successfully");
    } 

    @DeleteMapping("/DeleteRoom/{id}")
    public ResponseEntity<String> deleteRoom(@PathVariable("id") long id) {
        roomService.deleteRoom(id);
        return ResponseEntity.ok("Room deleted successfully");
    }
    
    @PostMapping("/Assign/{roomId}/patient/{patientId}")
    public ResponseEntity<Room> assignRoomToPatient(@PathVariable Long roomId, @PathVariable Long patientId) {
        Room updatedRoom = roomService.assignRoomToPatient(roomId, patientId);
        return ResponseEntity.ok(updatedRoom);
    }

    @PostMapping("/Release/{roomId}")
    public ResponseEntity<Room> releaseRoom(@PathVariable Long roomId) {
        Room updatedRoom = roomService.releaseRoom(roomId);
        return ResponseEntity.ok(updatedRoom);
    }

}
