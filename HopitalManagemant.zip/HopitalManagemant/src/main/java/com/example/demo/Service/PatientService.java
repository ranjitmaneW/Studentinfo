package com.example.demo.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.Entity.Bill;
import com.example.demo.Entity.Patient;
import com.example.demo.Entity.Room;
import com.example.demo.Repository.BillRepository;
import com.example.demo.Repository.PatientRepository;
import com.example.demo.Repository.RoomRepository;
@Service

public class PatientService {
	
	@Autowired
	
	PatientRepository patientRepository;
	
	@Autowired
	private RoomRepository roomRepository;
	 
	@Autowired
	private BillRepository billRepository;
	
	public Patient savePatientData(@RequestBody Patient patient) {
		return patientRepository.save(patient);
	}
	
	
	
	    public Patient savePatientWithBillsAndRoom(Patient patient) {
	        // Handle room assignment
	        Room room = patient.getRoom();
	        if (room != null) {
	            room.setOccupied(true);
	            room.setPatient(patient);  // set owning side
	        }

	        // Handle bills assignment
	        if (patient.getBills() != null) {
	            for (Bill bill : patient.getBills()) {
	                bill.setPatient(patient);  // set owning side
	            }
	        }

	        // Save patient (this cascades bills if CascadeType.ALL is set)
	        Patient savedPatient = patientRepository.save(patient);

	        // Make sure room is linked back and saved
	        if (room != null) {
	            roomRepository.save(room);
	        }

	        return savedPatient;
	    }

	
	public List<Patient> listOfPatients(){
		return patientRepository.findAll();
	}
	
	public Optional<Patient> getPatientDataById(@PathVariable("id")long id){
		return patientRepository.findById(id);
	}
	
	public String deletePatientDataById(@PathVariable("id")long id) {
		if(patientRepository.existsById(id)){
			
			patientRepository.deleteById(id);
					
					return " Patient record  deleted  by "+id+"  Successfully " ;
					
				}
				else
				{
					return "Patient record  not found";
					
				}
	}
	
	
	public String updatePatientDataById(@PathVariable("id") long id, @RequestBody Patient patient) {
	    Optional<Patient> byId = patientRepository.findById(id);
	    
	    if (byId.isPresent()) {
	        Patient patient1 = byId.get();
	        
	       
	        patient1.setName(patient.getName());
	        patient1.setAge(patient.getAge());
	        patient1.setGender(patient.getGender()); 
	        patient1.setContactNumber(patient.getContactNumber());
	        patient1.setEmail(patient.getEmail());
	        patient1.setAddress(patient.getAddress());
	        patient1.setBloodGroup(patient.getBloodGroup());
	        patient1.setDateOfRegistration(patient.getDateOfRegistration());
	        patient1.setMedicalHistory(patient.getMedicalHistory());

	       
	        patientRepository.save(patient1);

	        return "Patient data updated for ID: " + id;
	    } else {
	        return "Patient data not found for ID: " + id;
	    }
	}
	public Patient savePatient(Patient patient) {
	    Room room = patient.getRoom();

	    if (room != null) {
	        room = roomRepository.save(room);
	        room.setOccupied(true);
	        room.setPatient(patient);
	        patient.setRoom(room);
	    }

	    if (patient.getBills() != null) {
	        for (Bill bill : patient.getBills()) {
	            bill.setPatient(patient);
	        }
	    }

	    return patientRepository.save(patient);
	}

	
}
	
	

