package com.example.demo.SwaggerConfiguration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;

@Configuration
public class SwaggerConfig {
	
	@Bean
	 public OpenAPI customOpenAPI() {
       return new OpenAPI()
               .info(new Info()
                       .title("HospitalMgmt System API")
                       .description("API documentation for managing account data")
                       .version("2.2.0")
                       .contact(new Contact()
                               .name("Sakshi Sabiya")
                               .email("sm9292@gmail.com")
                               .url("https://google.com")
                       )
               );
   }

}
