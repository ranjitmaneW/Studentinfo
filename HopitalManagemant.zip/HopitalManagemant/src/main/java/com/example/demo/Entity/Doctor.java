package com.example.demo.Entity;

import java.util.List;

import com.example.demo.Enum.AppointmentMode;
import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity


public class Doctor {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	
	private Long id;
	private String name;
	private String email;    
	private String contactnumber;
	private String specialization;
    private List<String> availableDays;
	private String availableTime;
	private String roomNumber;
	
	@Enumerated(EnumType.STRING)
	private AppointmentMode appointmentMode;
	
	@OneToMany(mappedBy = "doctor", cascade = CascadeType.ALL)
    @JsonIgnore
    private List<Appointment> appointments;
	
	
/*
 specialization: String (e.g., Cardiologist, Dermatologist) 
 availableDays: List<String>
 availableTime: String
 roomNumber: String
 appointmentMode: Enum (ONLINE, OFFLINE, BOTH) */
	
	
	

}
