package com.example.demo.Enum;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum RoomType {
	GENERAL, ICU, PRIVATE;
	
	@JsonCreator
    public static RoomType fromString(String value) {
        return RoomType.valueOf(value.toUpperCase());
    }

}
