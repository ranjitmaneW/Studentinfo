package com.example.demo.Enum;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum Status {

	BOOKED,
	CANCELLED,
	COMPLETED;
	

	
	@JsonCreator
    public static Status fromString(String value) {
        return Status.valueOf(value.toUpperCase());
    }


}
