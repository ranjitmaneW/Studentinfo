package com.example.demo.Entity;

import java.time.LocalDate;
import java.util.List;


import com.example.demo.Enum.Gender;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity

@ToString
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Patient {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String name;
    private int age;

    @Enumerated(EnumType.STRING)
    private Gender gender;

    private String contactNumber;
    private String email;
    private String address;
    private String bloodGroup;
    private LocalDate dateOfRegistration;
    private String medicalHistory;


    /*@OneToMany(mappedBy = "patient", cascade = CascadeType.ALL)
   // @JsonIgnore

    @OneToMany(mappedBy = "patient", cascade = CascadeType.ALL)
   @JsonIgnore

    private List<Appointment> appointment;
    
    
    @OneToMany(mappedBy = "patient", cascade = CascadeType.ALL)
    private List<Bill> bills;

    
    @OneToOne(mappedBy = "patient")
    private Room room;*/
    
    @OneToOne(mappedBy = "patient")
    private Room room;


    @OneToMany(mappedBy = "patient", cascade = CascadeType.ALL)
    private List<Bill> bills;


    public void assignRoom(Room room) {
        this.room = room;
        room.setPatient(this);
    }

	

}