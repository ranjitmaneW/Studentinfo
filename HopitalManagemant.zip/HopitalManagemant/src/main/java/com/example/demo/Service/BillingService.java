package com.example.demo.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Appointment;
import com.example.demo.Entity.Bill;
import com.example.demo.Entity.Patient;
import com.example.demo.Enum.PaymentMethod;
import com.example.demo.Enum.Status1;
import com.example.demo.Repository.AppointmentRepository;
import com.example.demo.Repository.BillRepository;

import jakarta.persistence.EntityNotFoundException;

@Service
public class BillingService {

    @Autowired
    private BillRepository billRepository;

    @Autowired
	AppointmentRepository appointmentRepository;
	
    
    
    /*public Bill generateBill(Bill b) {
		return billRepository.save(b);
		
	}
	
	public Optional<Bill> getBillById(Long id){
		return billRepository.findById(id);
		
	}

    public String payBill(Long id,PaymentMethod m){
        return billRepository.
    }

    public String getBillsByPatient(Long patientId){
        return billRepository.findAll();
    }*/


/*public Bill generateBill(Long appointmentId, Bill b) {
    Appointment appointment = appointmentRepository.findById(appointmentId)
            .orElseThrow(() -> new RuntimeException("Appointment not found"));
    b.setAppointment(appointment);
    b.setStatus(Status1.UNPAID);
    return billRepository.save(b);
}*/
    
   

   /* public Bill saveBill(Bill bill) {
       
        Long appointmentId = bill.getAppointment().getId();
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new RuntimeException("Appointment not found"));

        bill.setAppointment(appointment);

        // Link patient (if not already set)
        if (bill.getPatient() == null && appointment.getPatient() != null) {
            bill.setPatient(appointment.getPatient());
        } else if (bill.getPatient() == null) {
            throw new RuntimeException("Patient must be provided for the bill");
        }
        
        return billRepository.save(bill);
    }*/
    
    public Bill saveBill(Bill bill) {
        Long appointmentId = bill.getAppointment().getId();
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new RuntimeException("Appointment not found"));

        bill.setAppointment(appointment);

        // Link patient from appointment if not provided
        Patient patient = appointment.getPatient();
        if (patient == null) {
            throw new RuntimeException("Appointment has no linked patient");
        }

        // Set both sides of the relationship
        bill.setPatient(patient);
        patient.getBills().add(bill);  // <-- important to maintain in-memory consistency

        return billRepository.save(bill);  // if CascadeType.ALL on patient.bills, you could also save patient
    }

    

    public Optional<Bill> getBillById(long id) {
        return billRepository.findById(id);
    }

    public Bill payBill(long id, PaymentMethod paymentMethod) {
        Optional<Bill> optionalBill = billRepository.findById(id);
        if (optionalBill.isPresent()) {
            Bill bill = optionalBill.get();
            bill.setPaymentMethod(paymentMethod);
            bill.setPaidDate(LocalDateTime.now());
            bill.setStatus(Status1.PAID);
            return billRepository.save(bill);
        }
        return null;
    }


    public List<Bill> getAllBills() {
        return billRepository.findAll();
    }
    
    
    public Bill updateBill(Long id, Bill bill) {
        return billRepository.findById(id)
                .map(existingBill -> {
                    existingBill.setAmount(bill.getAmount());
                    existingBill.setPaidDate(bill.getPaidDate());
                    existingBill.setStatus(bill.getStatus());
                    existingBill.setPaymentMethod(bill.getPaymentMethod());

                    // ✅ Safely handle the appointment reference
                    Long appointmentId = bill.getAppointment().getId();
                    Appointment existingAppointment = appointmentRepository.findById(appointmentId)
                            .orElseThrow(() -> new EntityNotFoundException("Appointment not found with id: " + appointmentId));
                    existingBill.setAppointment(existingAppointment);

                    return billRepository.save(existingBill);
                })
                .orElseThrow(() -> new EntityNotFoundException("Bill not found with id: " + id));
    }

    /*generateBill(Bill b)
  getBillById(Long id)
  payBill(Long id, PaymentMethod m)
  getBillsByPatient(Long patientId) */

}
