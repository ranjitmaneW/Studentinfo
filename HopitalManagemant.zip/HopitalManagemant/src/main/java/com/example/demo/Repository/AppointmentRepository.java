package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.Entity.Appointment;

@Repository

public interface AppointmentRepository extends JpaRepository<Appointment, Long>{

}
