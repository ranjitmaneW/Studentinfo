package com.example.demo.Enum;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum Category {
	MEDICINE, 
	EQUIPMENT;
	
	 @JsonCreator
	    public static Category fromString(String value) {
	        return Category.valueOf(value.toUpperCase());
	    }

}
