package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.ApiResponse.ApiResponse;
import com.example.demo.Entity.Inventory;
import com.example.demo.Service.InventoryService;

@RestController
public class InventoryController {

    @Autowired
    private InventoryService inventoryService;

    
    @PostMapping("/InsertInventoryData")
	public ResponseEntity<ApiResponse> savedata(@RequestBody Inventory i){
		Inventory inventorydata=inventoryService.addInventory(i);
		ApiResponse response=new ApiResponse("Inventory created ", HttpStatus.CREATED.value(), inventorydata);
		return ResponseEntity.status(HttpStatus.CREATED).body(response);
		
	}
	
	@GetMapping("/InventoryList")
	public ResponseEntity<ApiResponse> getalldatalist(){
		List<Inventory> getlist =inventoryService.getAllInventory();
		ApiResponse response = new ApiResponse("Data retrived Successfully",HttpStatus.ACCEPTED.value(), getlist);
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(response);
		
	}

    @PutMapping("/UpdateInventory/{id}")
    public ResponseEntity<ApiResponse> updateInventory(@PathVariable("id") long id,@RequestBody Inventory i){
        String updatInventory=inventoryService.updateInventory(id, i);
        ApiResponse response = new ApiResponse("Data Updated Successfully", HttpStatus.ALREADY_REPORTED.value(), updatInventory);
        return ResponseEntity.status(HttpStatus.ALREADY_REPORTED).body(response);
    }

}
