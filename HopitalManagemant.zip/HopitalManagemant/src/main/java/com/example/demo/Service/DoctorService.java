package com.example.demo.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Doctor;
import com.example.demo.Repository.DoctorRepository;


@Service
public class DoctorService {
	
	@Autowired
	private DoctorRepository doctorRepository;
	
	public Doctor addDoctor(Doctor d) {
		return doctorRepository.save(d);		
	}
	
	public List<Doctor> getAllDoctors() {
		return doctorRepository.findAll();
	}
	
	public Optional<Doctor> getDoctorById(Long id) {
		return doctorRepository.findById(id);
		
	}
	
	public List<Doctor> getDoctorBySpecialization(String spec) {
		return doctorRepository.findBySpecialization(spec);
		
	}
	
	
	public String updateDoctor(Long id,Doctor d) {
		Optional<Doctor> byId=doctorRepository.findById(id);
		if(byId.isPresent())
		{
			Doctor doctor = byId.get();
			doctor.setName(d.getName());
			doctor.setContactnumber(d.getContactnumber());
            doctor.setEmail(d.getEmail());
            doctor.setSpecialization(d.getSpecialization());
            doctor.setAppointmentMode(d.getAppointmentMode());
            doctor.setAvailableTime(d.getAvailableTime());
            doctor.setAvailableDays(d.getAvailableDays());
			doctor.setRoomNumber(d.getRoomNumber());
			
			doctorRepository.save(doctor);
			return " Doctor id updated:" +id;
		}
		else
		{
			return "Doctor id not found :" +id;
		}
		
	}
	/*addDoctor(Doctor d)
	  updateDoctor(Long id, Doctor d)
	  getDoctorBySpecialization(String spec)
	  getAllDoctors()
	  getDoctorById(Long id)*/

}
