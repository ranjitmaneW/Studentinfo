package com.example.demo.Repository;

//import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.Entity.Bill;

@Repository

public interface BillRepository extends JpaRepository<Bill, Long> {

    //List<Bill> findByPatientId(Long patientId);

}
