package com.example.demo.ApiResponse;

public class ApiResponse {
	
	
	private String message;
	private int statuscode;
	private Object data;
	
	public ApiResponse(String message,int statuscode,Object data) {
		this.message=message;
		this.statuscode=statuscode;
		this.data=data;		
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public int getStatuscode() {
		return statuscode;
	}

	public void setStatuscode(int statuscode) {
		this.statuscode = statuscode;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	
	@Override
	public String toString() {
		return "ApiResponse [message=" + message + ", statuscode=" + statuscode + ", data=" + data + ", getMessage()="
				+ getMessage() + ", getStatuscode()=" + getStatuscode() + ", getData()=" + getData() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

}
