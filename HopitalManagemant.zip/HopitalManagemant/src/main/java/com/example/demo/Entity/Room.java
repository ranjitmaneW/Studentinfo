package com.example.demo.Entity;

import com.example.demo.Enum.RoomType;
import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@ToString
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class Room {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	private String roomNumber;

	@Enumerated(EnumType.STRING)
	private RoomType roomType;

	private boolean occupied;
	
	/*@OneToOne(mappedBy = "room")
	//private Patient patient;  //patient: Patient (OneToOne, nullable)
   
    @OneToOne
    @JoinColumn(name = "patient_id", referencedColumnName = "id")
	private Patient patient;*/
    
	
	@OneToOne
    @JoinColumn(name = "patient_id", referencedColumnName = "id")
	@JsonIgnore
    private Patient patient;

	/*id: Long
  roomNumber: String
  roomType: Enum (GENERAL, ICU, PRIVATE)
  occupied: Boolean	
  patient: Patient (OneToOne, nullable) */

}
