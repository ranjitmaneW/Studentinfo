package com.example.demo.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.ApiResponse.ApiResponse;
import com.example.demo.Entity.Bill;
import com.example.demo.Entity.Doctor;
import com.example.demo.Enum.PaymentMethod;
import com.example.demo.Service.BillingService;

@RestController
public class BillController {
	
    @Autowired
    private BillingService billingService;
    
     
     @PostMapping("/CreateBills")
     public ResponseEntity<Bill> createBill(@RequestBody Bill bill) {
         Bill savedBill = billingService.saveBill(bill);
         return ResponseEntity.status(HttpStatus.CREATED).body(savedBill);
     }


    @GetMapping("/BillById/{id}")
    public ResponseEntity<ApiResponse> getBillById(@PathVariable Long id) {
        Optional<Bill> bill = billingService.getBillById(id);
        return ResponseEntity.status(HttpStatus.OK)
                .body(new ApiResponse("Bill fetched successfully", HttpStatus.OK.value(), bill));
    }

    @PutMapping("/PayBill/{id}")
    public ResponseEntity<ApiResponse> payBill(@PathVariable Long id, @RequestParam PaymentMethod method) {
        Bill updatedBill = billingService.payBill(id, method);
        return ResponseEntity.status(HttpStatus.OK)
                .body(new ApiResponse("Bill payment successful", HttpStatus.OK.value(), updatedBill));
    }
    
    @PutMapping("/UpdateBill/{id}")
    public ResponseEntity<ApiResponse> updatebill(@PathVariable("id") long id,@RequestBody Bill bill){
        Bill updatebill=billingService.updateBill(id, bill);
        ApiResponse response = new ApiResponse("Data Updated Successfully", HttpStatus.ALREADY_REPORTED.value(), updatebill);
        return ResponseEntity.status(HttpStatus.ALREADY_REPORTED).body(response);
    }

   /* @GetMapping("/BillsByPatient/{patientId}")
    public ResponseEntity<ApiResponse> getBillsByPatient(@PathVariable Long patientId) {
        List<Bill> bills = billingService.getBillsByPatient(patientId);
        return ResponseEntity.status(HttpStatus.OK)
                .body(new ApiResponse("Patient bills retrieved", HttpStatus.OK.value(), bills));
    }*/

    @GetMapping("/BillsList")
    public ResponseEntity<ApiResponse> getAllBills() {
        List<Bill> bills = billingService.getAllBills();
        return ResponseEntity.status(HttpStatus.OK)
                .body(new ApiResponse("All bills retrieved", HttpStatus.OK.value(), bills));
    }


    

}
