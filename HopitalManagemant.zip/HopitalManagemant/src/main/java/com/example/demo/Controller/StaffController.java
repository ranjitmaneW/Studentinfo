package com.example.demo.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.ApiResponse.ApiResponse;
import com.example.demo.Entity.Prescription;
import com.example.demo.Entity.Staff;
import com.example.demo.Service.StaffService;

@RestController

public class StaffController {
	
	@Autowired
	
	StaffService staffService;
	
	
	@PostMapping("/InsertStaffData")
	
	 public ResponseEntity<ApiResponse> saveStaffData(@RequestBody Staff staff){
		Staff savesdata=staffService.saveStaffData(staff);
	    	ApiResponse response=new ApiResponse("Staff Data Inserted",201,savesdata);
			return ResponseEntity.status(HttpStatus.CREATED).body(response);
	    	
	    }
	
	@GetMapping("/StaffList")
	

	 public ResponseEntity<ApiResponse> getStaffData(){
		List<Staff> getsdata=staffService.listOfStaff();
	    	ApiResponse response=new ApiResponse("Staff List Created ",202,getsdata);
			return ResponseEntity.status(HttpStatus.OK).body(response);
	    	
	    }
	
	@GetMapping("/GetStaffById/{id}")
	
	public ResponseEntity<ApiResponse> getPDataById(@PathVariable("id")long id){
		Optional<Staff> getSById=staffService.getStaffDataById(id);
	    	ApiResponse response=new ApiResponse("Get Staff Data By Id ",204,getSById);
			return ResponseEntity.status(HttpStatus.ACCEPTED).body(response);
	    	
	    }
	@DeleteMapping("/DeleteStaffById/{id}")
	
	 public ResponseEntity<ApiResponse> deletePData(@PathVariable("id")long id){
		String deleteSById=staffService.deleteStaffDataById(id);
	    	ApiResponse response=new ApiResponse("Deleted Staff Data By Id ",202,deleteSById);
			return ResponseEntity.status(HttpStatus.OK).body(response);
	    	
	    }
	
	@PutMapping("/UpdateStaffDataById/{id}")
	
	 public ResponseEntity<ApiResponse> updateSData(@PathVariable("id")long id,@RequestBody Staff staff){
		String updateSById=staffService.updateStaffDataById(id, staff);
	    	ApiResponse response=new ApiResponse("Updated Prescription Data By Id ",202,updateSById);
			return ResponseEntity.status(HttpStatus.OK).body(response);
	    	
	    }
	

}
