package com.example.demo.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.Entity.Inventory;
import com.example.demo.Repository.InventoryRepository;

@Service

public class InventoryService {
	
	@Autowired
	
	private InventoryRepository inventoryRepository;
	
	public Inventory addInventory(Inventory i) {
		return inventoryRepository.save(i);
		
	}
	
	public List<Inventory> getAllInventory(){
		return inventoryRepository.findAll();
		
	}

    public String updateInventory(long id,Inventory i) {
		Optional<Inventory> byId=inventoryRepository.findById(id);
		if(byId.isPresent())
		{
			Inventory inventory = byId.get();
			inventory.setItemName(i.getItemName());
			inventory.setCategory(i.getCategory());
			inventory.setQuantityAvailable(i.getQuantityAvailable());
			inventory.setExpiryDate(i.getExpiryDate());
            inventory.setManufacturer(i.getManufacturer());
           
		
			inventoryRepository.save(inventory);
			
		
		return " Inventory updated:" +id;
		}
		else
		{
			return "Inventory not found :" +id;
		}
    }
	
	/*addInventory(Inventory i)
	  updateInventory(Long id, Inventory i)
	  getAllInventory()*/

}

