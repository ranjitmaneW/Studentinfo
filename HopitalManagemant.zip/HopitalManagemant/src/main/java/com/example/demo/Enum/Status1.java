package com.example.demo.Enum;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum Status1 {
	PAID,
	UNPAID;
	
	@JsonCreator
	public static Status1 fromString(String value) {
        return Status1.valueOf(value.toUpperCase());
    }

}
