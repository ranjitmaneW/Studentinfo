package com.example.demo.Enum;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum Role {
	ADMIN,
	DOCTOR,
	NURSE,
	RECEPTIONIST;
	



	 @JsonCreator
	    public static Role fromString(String value) {
	        return Role.valueOf(value.toUpperCase());
	    }
}