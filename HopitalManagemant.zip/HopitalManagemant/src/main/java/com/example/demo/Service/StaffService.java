package com.example.demo.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.Entity.Patient;
import com.example.demo.Entity.Staff;
import com.example.demo.Repository.StaffRepository;

@Service

public class StaffService {
	
	@Autowired 
	
	StaffRepository staffRepository;
	

	public Staff saveStaffData(@RequestBody Staff staff) {
		return staffRepository.save(staff);
	}
	
	public List<Staff> listOfStaff(){
		return staffRepository.findAll();
	}
	
	public Optional<Staff> getStaffDataById(@PathVariable("id")long id){
		return staffRepository.findById(id);
	}
	
	public String deleteStaffDataById(@PathVariable("id")long id) {
		if(staffRepository.existsById(id)){
			
			staffRepository.deleteById(id);
					
					return "Staff record  deleted  by "+id+"  Successfully " ;
					
				}
				else
				{
					return "Staff record  not found";
					
				}
	}
	
	
	public String updateStaffDataById(@PathVariable("id") long id, @RequestBody Staff staff) {
	    Optional<Staff> byId = staffRepository.findById(id);
	    
	    if (byId.isPresent()) {
	    	Staff staff1 = byId.get();
	        
	       
	    	staff1.setName(staff.getName());
	    	staff1.setRole(staff.getRole()); 
	    	staff1.setEmail(staff.getEmail());
	    	staff1.setPassword(staff.getPassword());
	    	staff1.setContactNumber(staff.getContactNumber());
	    	
	       
	        staffRepository.save(staff1);

	        return "Staff data updated for ID: " + id;
	    } else {
	        return "Staff data not found for ID: " + id;
	    }
	}

		
		
	
	

}
