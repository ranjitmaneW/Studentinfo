package com.example.demo.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Patient;
import com.example.demo.Entity.Room;
import com.example.demo.Enum.RoomType;
import com.example.demo.Repository.PatientRepository;
import com.example.demo.Repository.RoomRepository;

@Service
public class RoomService {
    @Autowired
    private RoomRepository roomRepository;
    
    @Autowired
    private PatientRepository patientRepository;

    
    public Room saveRoom(Room room) {
        return roomRepository.save(room);
    }

    
    public List<Room> getAllRooms() {
        return roomRepository.findAll();
    }

    
    public Room assignRoomToPatient(Long roomId, Long patientId) {
        Room room = roomRepository.findById(roomId)
            .orElseThrow(() -> new RuntimeException("Room not found"));

        Patient patient = patientRepository.findById(patientId)
            .orElseThrow(() -> new RuntimeException("Patient not found"));

        if (room.isOccupied()) {
            if (!room.getRoomType().equals(RoomType.GENERAL)) {
                throw new RuntimeException("Room is already occupied");
            }
            // For GENERAL rooms, optionally add to a collection or just log
        }

        room.setPatient(patient);
        room.setOccupied(true);
        patient.setRoom(room);  // make sure both sides are set!

        roomRepository.save(room);  // important: save the owning side

        return room;
    }



    public Room releaseRoom(Long roomId) {
        Room room = roomRepository.findById(roomId)
            .orElseThrow(() -> new RuntimeException("Room not found"));

        room.setPatient(null);
        room.setOccupied(false);

        return roomRepository.save(room);
    }



    public void deleteRoom(long id) {
        roomRepository.deleteById(id);
    }

    public List<Room> getAvailableRooms() {
        return roomRepository.findByOccupiedFalse();
    }

    public String updateRoom(long id,Room room) {
		Optional<Room> byId=roomRepository.findById(id);
		if(byId.isPresent())
		{
			Room room1 = byId.get();
			room1.setRoomNumber(room.getRoomNumber());
			room1.setRoomType(room.getRoomType());
            
			roomRepository.save(room1);
			return " Room id updated:" +id;
		}
		else
		{
			return "Room id not found :" +id;
		}

    /* assignRoom(Long roomId, Long patientId)
  vacateRoom(Long roomId)
  getAvailableRooms() */

}}
