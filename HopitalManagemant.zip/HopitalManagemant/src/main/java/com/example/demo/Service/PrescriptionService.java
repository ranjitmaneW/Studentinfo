package com.example.demo.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.Entity.Appointment;
import com.example.demo.Entity.Prescription;
import com.example.demo.Repository.AppointmentRepository;
import com.example.demo.Repository.PrescriptionRepository;

@Service
public class PrescriptionService {
	
	@Autowired
	PrescriptionRepository prescriptionRepository;
	
	
	@Autowired
	AppointmentRepository appointmentRepository;
	
	
	/*public Prescription saveData(@RequestBody Prescription prescription) {
		return prescriptionRepository.save(prescription);
	}*/
	
	public Prescription saveData(Prescription prescription) {
	    Long Id = prescription.getAppointment().getId();
	    Appointment appointment = appointmentRepository.findById(Id)
	            .orElseThrow(() -> new RuntimeException("Appointment not found"));
	    prescription.setAppointment(appointment);
	    return prescriptionRepository.save(prescription);
	}

	
	public List<Prescription> listOfPrescription(){
		return prescriptionRepository.findAll();
		
	}
	
	public Optional<Prescription> getPrescriptionDataById(@PathVariable("id")long id){
		return prescriptionRepository.findById(id);
	}
	
	public String deletePrescriptionDataById(@PathVariable("id")long id) {
		if(prescriptionRepository.existsById(id)){
			
			prescriptionRepository.deleteById(id);
					
					return " Prescription record  deleted  by "+id+"  Successfully " ;
					
				}
				else
				{
					return "Prescription record  not found";
					
				}
	}
	
	
	public String updatePrescriptionDataById(@PathVariable("id") long id, @RequestBody Prescription prescription) {
	    Optional<Prescription> byId = prescriptionRepository.findById(id);
	    
	    if (byId.isPresent()) {
	    	Prescription prescription1 = byId.get();
	        
	       
	    	 prescription1.setAppointment( prescription.getAppointment());
	    	 prescription1.setDiagnosis(prescription.getDiagnosis());
	    	 prescription1.setMedicines(prescription.getMedicines()); 
	    	 prescription1.setTestRecommended(prescription.getTestRecommended());
	    	 prescription1.setNotes(prescription.getNotes());
	    	
	       
	    	 prescriptionRepository.save(prescription1);

	        return " Prescription data updated for ID: " + id;
	    } else {
	        return "Prescription data not found for ID: " + id;
	    }
	}
}


