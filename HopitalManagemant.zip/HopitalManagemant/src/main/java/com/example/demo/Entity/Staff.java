package com.example.demo.Entity;

import java.util.List;

import com.example.demo.Enum.AppointmentMode;
import com.example.demo.Enum.Gender;
import com.example.demo.Enum.Role;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
@ToString
@AllArgsConstructor
@NoArgsConstructor

@Data
@Entity
public class Staff {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	
	private Long id;
	private String name;

    @Enumerated(EnumType.STRING)
    private Role role;

	private String email;
	private String password;
	private String contactNumber;
	

}
