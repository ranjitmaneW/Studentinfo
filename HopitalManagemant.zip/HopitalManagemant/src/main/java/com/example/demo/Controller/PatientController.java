package com.example.demo.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.ApiResponse.ApiResponse;
import com.example.demo.Entity.Patient;
import com.example.demo.Service.PatientService;

@RestController

public class PatientController {
	
	@Autowired
	
	PatientService patientService;
	
	
	
	@PostMapping("/patients")
	public ResponseEntity<Patient> createPatient(@RequestBody Patient patient) {
	    Patient savedPatient = patientService.savePatientWithBillsAndRoom(patient);
	    return ResponseEntity.status(HttpStatus.CREATED).body(savedPatient);
	}

	@PostMapping("/InsertPatientData")
	
	/*public  Patient saveData (@RequestBody Patient patient ) {
		return patientService.savePatientData(patient);
		
	}*/
	
	 public ResponseEntity<ApiResponse> saveData(@RequestBody Patient patient){
		Patient savedata=patientService.savePatientData(patient);
	    	ApiResponse response=new ApiResponse("Patient Data Inserted",201,savedata);
			return ResponseEntity.status(HttpStatus.CREATED).body(response);
	    	
	    }
	
	@GetMapping("/PatientList")
	
	/*public List<Patient> getAllData(){
		return patientService.listOfPatients();
		
		
	}*/
	
	 public ResponseEntity<ApiResponse> getAllData(){
		List<Patient> getData=patientService.listOfPatients();
	    	ApiResponse response=new ApiResponse("Patient List Created ",202,getData);
			return ResponseEntity.status(HttpStatus.OK).body(response);
	    	
	    }
	
	
	@GetMapping("/GetPatientDataById/{id}")
	
	/*public Optional<Patient> getDataById(@PathVariable("id")long id){
		return patientService.getPatientDataById(id);
		
	}*/

	 public ResponseEntity<ApiResponse> getDataById(@PathVariable("id")long id){
		Optional<Patient> getById=patientService.getPatientDataById(id);
	    	ApiResponse response=new ApiResponse("Get Patient Data By Id ",204,getById);
			return ResponseEntity.status(HttpStatus.ACCEPTED).body(response);
	    	
	    }
	
	
	@DeleteMapping("/DeletePatientById/{id}")
	
	/*public String deleteDataById(@PathVariable("id")long id) {
		return patientService.deletePatientDataById(id);
		
	}*/
	

	 public ResponseEntity<ApiResponse> deleteData(@PathVariable("id")long id){
		String deleteById=patientService.deletePatientDataById(id);
	    	ApiResponse response=new ApiResponse("Deleted Patient Data By Id ",202,deleteById);
			return ResponseEntity.status(HttpStatus.OK).body(response);
	    	
	    }
	
	
	@PutMapping("/UpdatePatientById/{id}")
	
	/*public String updateById(@PathVariable("id")long id,@RequestBody Patient patient) {
		return patientService.updatePatientDataById(id, patient);
		
	}*/
	

	 public ResponseEntity<ApiResponse> updateData(@PathVariable("id")long id,@RequestBody Patient patient){
		String updateById=patientService.updatePatientDataById(id, patient);
	    	ApiResponse response=new ApiResponse("Updated Patient Data By Id ",202,updateById);
			return ResponseEntity.status(HttpStatus.OK).body(response);
	    	
	    }

	
	 /*@PostMapping("/{patientId}/add-bill")
	    public String addBill(@PathVariable Long patientId, @RequestParam Double amount, @RequestParam PaymentMethod paymentMethod) {
	        patientService.addBillToPatient(patientId, amount, paymentMethod);
	        return "Bill added to patient successfully!";
	    }

	    @PostMapping("/{patientId}/assign-room/{roomId}")
	    public String assignRoom(@PathVariable Long patientId, @PathVariable Long roomId) {
	        patientService.assignRoomToPatient(patientId, roomId);
	        return "Room assigned to patient successfully!";
	    }*/
}
