package com.example.demo.Entity;

import java.time.LocalDate;

import com.example.demo.Enum.Category;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class Inventory {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	
	private Long id;
	private String itemName;
	
	@Enumerated(EnumType.STRING)
	private Category category;
	
	private int quantityAvailable;
	private LocalDate expiryDate;
	private String manufacturer;
	

}
